// ignore_for_file: prefer_const_constructors, use_build_context_synchronously, deprecated_member_use, sort_child_properties_last

import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:dressur/1_reception/liste_contact.dart';
import 'package:dressur/2_promo/new_boost_contact.dart';
// import 'package:dressur/5_autre/cart_visite.dart';
import 'package:dressur/5_autre/profil_user.dart';
import 'package:dressur/components/padding_and_divider.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_linkify/flutter_linkify.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:dressur/5_autre/confirme_mail_user.dart';
import 'package:dressur/1_reception/liste_notification.dart';
import 'package:dressur/components/constant.dart';
import 'package:http/http.dart' as http;
import 'dart:convert' as convert;
import 'package:flutter_contacts/flutter_contacts.dart';
import 'package:dressur/components/sociaux.dart';
import 'package:dressur/components/sql_helper.dart';
import 'package:dressur/5_autre/support_assistance.dart';
import 'package:url_launcher/url_launcher.dart';

class AnimatedRewardBadge extends StatefulWidget {
  final VoidCallback onTap;
  const AnimatedRewardBadge({Key? key, required this.onTap}) : super(key: key);

  @override
  State<AnimatedRewardBadge> createState() => _AnimatedRewardBadgeState();
}

class _AnimatedRewardBadgeState extends State<AnimatedRewardBadge>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _scaleAnimation;
  late Animation<double> _glowAnimation;
  late Animation<Color?> _colorAnimation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2000),
    )..repeat(reverse: true);

    _scaleAnimation = Tween<double>(begin: 1.0, end: 1.12).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeInOut),
    );

    _glowAnimation = Tween<double>(begin: 5.0, end: 18.0).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeInOut),
    );

    // Animation de couleur entre la couleur primaire et une variante plus vive (dorée/orange)
    _colorAnimation = ColorTween(
      begin: primaryColor,
      end: Colors
          .red, // Vous pouvez changer pour Colors.amber ou une autre couleur vive
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.linear));
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, child) {
        final currentColor = _colorAnimation.value ?? primaryColor;

        return Transform.scale(
          scale: _scaleAnimation.value,
          child: GestureDetector(
            onTap: widget.onTap,
            child: Container(
              padding: const EdgeInsets.all(5),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(
                  colors: [
                    currentColor.withOpacity(0.95),
                    currentColor.withOpacity(0.7),
                  ],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                border: Border.all(
                  color: Colors.white.withOpacity(0.9),
                  width: 1,
                ),
                boxShadow: [
                  // Lueur colorée animée
                  BoxShadow(
                    color: currentColor.withOpacity(0.6),
                    blurRadius: _glowAnimation.value,
                    spreadRadius: _glowAnimation.value / 3,
                  ),
                  BoxShadow(
                    color: Colors.black.withOpacity(0.3),
                    blurRadius: 10,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: const Icon(
                Icons.stars,
                color: Colors.white,
                size: 20,
              ),
            ),
          ),
        );
      },
    );
  }
}

class Advertisement {
  final String uidUser;
  final int id;
  final String image;
  final String imageName;
  final String description;
  final String whatsappNumber;
  final String pseudoAnnonceur;
  final String nombreDeVues;
  final String nombreImpression;
  final String typePromotionAffaire;
  final String annotherInfo;
  final bool inProgrammeRecompense;

  Advertisement({
    required this.uidUser,
    required this.id,
    required this.image,
    required this.imageName,
    required this.description,
    required this.whatsappNumber,
    required this.pseudoAnnonceur,
    required this.nombreDeVues,
    required this.nombreImpression,
    required this.typePromotionAffaire,
    required this.annotherInfo,
    required this.inProgrammeRecompense,
  });
}

class ActuPage extends StatefulWidget {
  ActuPage({Key? key}) : super(key: key);

  @override
  State<ActuPage> createState() => _ActuPageState();
}

class _ActuPageState extends State<ActuPage> {
  final ScrollController _scrollController = ScrollController();

  final ValueNotifier<bool> _showFabText = ValueNotifier(true);
  bool _loading = false;
  List<Map<String, dynamic>> historiqueContactsAdd = [];
  Timer? _timer;

  bool havePublicites = false;
  bool rechercheEnCours = true;
  late Future<List<Advertisement>> _futureAdvertisements;
  bool _firstLoad = true;

  @override
  void initState() {
    super.initState();
    _futureAdvertisements = fetchAdvertisements();
    _scrollController.addListener(_scrollListener);
    // Démarre le timer lors de l'initialisation du widget
    _startTimer();
  }

  @override
  void dispose() {
    _scrollController.removeListener(_scrollListener);
    _scrollController.dispose();
    _showFabText.dispose();
    // Arrête le timer lors de la suppression du widget
    _stopTimer();
    super.dispose();
  }

  void showWarningDialog(BuildContext context) {
    int countdown = 5;

    showDialog(
      context: context,
      barrierDismissible: false, // ❌ clic extérieur désactivé
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setState) {
            // Timer déclenché une seule fois
            Future.delayed(const Duration(seconds: 1), () {
              if (countdown > 0) {
                setState(() => countdown--);
              }
            });

            return WillPopScope(
              onWillPop: () async => false, // ❌ bouton retour désactivé
              child: AlertDialog(
                // backgroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                  side: const BorderSide(color: Colors.red),
                ),
                title: Row(
                  children: [
                    const Icon(Icons.warning_amber_rounded, color: Colors.red),
                    const SizedBox(width: 8),
                    Text(
                      "Avertissement important",
                      style:
                          GoogleFonts.poppins(color: Colors.red, fontSize: 16),
                    ),
                  ],
                ),
                content: const Text(
                  "Dressur ne peut garantir la fiabilité ou la moralité des utilisateurs.\n\n"
                  "Il est fortement conseillé de ne jamais envoyer de l’argent pour un service "
                  "sans être certain de pouvoir entrer en possession de ce pour quoi vous payez.\n\n"
                  "Dressur décline toute responsabilité en cas d’arnaque ou de perte financière "
                  "causée par un autre utilisateur.",
                ),
                actions: [
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.red,
                    ),
                    onPressed: countdown == 0
                        ? () => Navigator.of(context).pop()
                        : null,
                    child: Text(
                      countdown > 0 ? "Fermer ($countdown)" : "Fermer",
                      style: GoogleFonts.poppins(color: Colors.white),
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  void _scrollListener() {
    if (_scrollController.position.userScrollDirection ==
        ScrollDirection.reverse) {
      _showFabText.value = false;
    } else if (_scrollController.position.atEdge &&
        _scrollController.position.pixels == 0) {
      _showFabText.value = true;
    }
  }

  Future<void> _refreshData() async {
    setState(() {
      actualise(true);
    });
  }

  void _startTimer() {
    _timer = Timer.periodic(Duration(seconds: 1), (timer) {
      setState(() {
        nombreContactDispo = nombreContactDispo;
      });
    });
  }

  void _stopTimer() {
    // Arrête et annule le timer
    _timer?.cancel();
    _timer = null;
  }

  void actualise(affMessage) async {
    if (affMessage == true) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        backgroundColor: Colors.red,
        behavior: SnackBarBehavior.floating,
        content: Text(
          (langUserPhone == "fr")
              ? 'Actualisation en cours…'
              : 'Update in progress…',
          style: GoogleFonts.poppins(
            color: Colors.white,
          ),
        ),
      ));
    }
    setState(() {
      _loading = true;
    });

    var request = http.MultipartRequest(
        'POST', Uri.parse('$generalRouteForApi/getUserInfo'));
    request.fields
        .addAll({'uid': uidUser, 'langUserPhone': langUserPhone.toString()});

    http.StreamedResponse response = await request.send();

    if (response.statusCode == 200) {
      var data1 = await response.stream.bytesToString();
      var data = convert.jsonDecode(data1);
      if (data["error"] == false) {
        setState(() {
          initUserInformations(data['user']);
          lesPublicites = data['user']["lesPublicites"];
          print(jsonDecode(lesPublicites).length);
          _futureAdvertisements = fetchAdvertisements();
          _loading = false;
        });
      } else {
        setState(() {
          _loading = false;
        });
      }
    } else {
      setState(() {
        _loading = false;
      });
    }
    if (affMessage == true) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          backgroundColor: Colors.green,
          behavior: SnackBarBehavior.floating,
          content: Text(
            (langUserPhone == "fr")
                ? 'Actualisation terminée.'
                : 'Refresh complete.',
            style: GoogleFonts.poppins(
              color: Colors.white,
            ),
          ),
        ),
      );
    }
  }

  Future<List<Advertisement>> fetchAdvertisements() async {
    if (nbrAffichageAvertissement == 0) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        showWarningDialog(context);
      });
    }

    setState(() {
      nbrAffichageAvertissement++;
    });

    if (lesPublicites.toString().isNotEmpty) {
      havePublicites = true;
      final jsonData = jsonDecode(lesPublicites) as List<dynamic>;
      final advertisements = jsonData.map((data) {
        return Advertisement(
          uidUser: data['uidUser'],
          id: data['id'],
          imageName: data['image'],
          image: generalRouteForPromotionImage + data['image'],
          description: data['description'],
          whatsappNumber: data['whatsappNumber'],
          pseudoAnnonceur: data['pseudoAnnonceur'],
          nombreDeVues: data['nombreDeVues'],
          nombreImpression: data['nombreImpression'],
          typePromotionAffaire: data['typePromotionAffaire'],
          annotherInfo: data['annotherInfo'] != null
              ? jsonEncode(data['annotherInfo'])
              : "",
          inProgrammeRecompense: data['inProgrammeRecompense'] == 1,
        );
      }).toList();
      // Mélanger l'ordre des éléments
      advertisements.shuffle();
      return advertisements;
    } else {
      havePublicites = false;
      return []; // Retourne une liste vide si aucune annonce n'est disponible
    }
  }

  Future<void> setPromotionToWatch(Advertisement advertisement) async {
    // Faites votre requête HTTP ici
    if (advertisement.uidUser != uidUser) {
      final response = await http.get(Uri.parse(
          '$generalRouteForApi/setPromotionToWatch/${advertisement.id}/$uidUser'));
      if (response.statusCode == 200) {
        // print(advertisement.id);
      }
    }
  }

  void _showMessagePasPermiAdd(message, context) async {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(20.0),
          topRight: Radius.circular(20.0),
        ),
      ),
      elevation: 5,
      isScrollControlled: true,
      builder: (_) => Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Colors.red,
              Colors.redAccent,
            ],
          ),
        ),
        padding: EdgeInsets.only(
          top: 0,
          left: 0,
          right: 0,
          // this will prevent the soft keyboard from covering the text fields
          bottom: MediaQuery.of(context).viewInsets.bottom + 0,
        ),
        child: Container(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 16),
          child: Text(
            message,
            style: GoogleFonts.poppins(
              fontSize: 14,
              color: Colors.white,
            ),
            textAlign: TextAlign.justify,
          ),
        ),
      ),
    );
  }

  void addTousLesContacts() async {
    setState(() {
      _loading = true;
    });
    var request = http.MultipartRequest(
        'POST',
        Uri.parse(
            '$generalRouteForApi/addTousUserContact/$uidUser/${langUserPhone.toString()}'));
    request.fields.addAll({
      'uid': uidUser,
      'langUserPhone': langUserPhone.toString(),
    });

    http.StreamedResponse response = await request.send();

    if (response.statusCode == 200) {
      var data1 = await response.stream.bytesToString();
      var data = jsonDecode(data1);
      if (data["error"] == true) {
        if (data["permissionAdd"] == false) {
          setState(() {
            permissionAdd = false;
            messageErreurPermissionAdd = data["messageErreurPermissionAdd"];
          });
          await saveContactsAddsIfExiste(data);
          // tu a deja depasser
          _showMessagePasPermiAdd(messageErreurPermissionAdd, context);
        }
      } else if (data["error"] == false) {
        await saveContactsAddsIfExiste(data);
      } else {
        // erreur server heinnn
      }

      setState(() {
        _loading = false;
      });
    } else {
      setState(() {
        _loading = false;
      });
    }
  }

  Future<void> saveContactsAddsIfExiste(data) async {
    int nombreAddNow = 0;
    if ((data["contactsAdd"]).length >= 1) {
      for (var contactAdd in data["contactsAdd"]) {
        if ((await SQLHelper.getOneNumsTelUser(contactAdd['tel'])).isEmpty) {
          final newContact = Contact()
            ..name.first = contactAdd["nom"] + " #DS"
            ..phones = [Phone(contactAdd["tel"])];
          await newContact.insert();
          await insertNumTelUserIntoDataBase(contactAdd["tel"]);
        }
      }
      setState(() {
        nombreAddNow = (data["contactsAdd"]).length;
        nombreContactDispo = nombreContactDispo - nombreAddNow;
      });
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        backgroundColor: Colors.green,
        behavior: SnackBarBehavior.floating,
        duration: const Duration(seconds: 15),
        content: Text(
          (langUserPhone == "fr")
              ? 'ADD de $nombreAddNow contact(s) avec succès.'
              : 'ADD of $nombreAddNow contacts successfully.',
          style: GoogleFonts.poppins(
            color: Colors.white,
          ),
        ),
      ));
    }
  }

  Future<bool> _onWillPop() async {
    return (await showDialog(
          context: context,
          builder: (context) => AlertDialog(
            title: (langUserPhone == "fr")
                ? const Text('Êtes-vous sûr?')
                : const Text('Are you sure?'),
            content: (langUserPhone == "fr")
                ? const Text("Voulez-vous quitter l'application ?")
                : const Text("Do you want to quit the application ?"),
            actions: <Widget>[
              TextButton(
                onPressed: () =>
                    Navigator.of(context).pop(false), //<-- SEE HERE
                child: (langUserPhone == "fr")
                    ? const Text('Non')
                    : const Text('No'),
              ),
              TextButton(
                onPressed: () {
                  if (Platform.isAndroid) {
                    SystemNavigator.pop();
                  } else if (Platform.isIOS) {
                    exit(0);
                  }
                }, // <-- SEE HERE
                child: (langUserPhone == "fr")
                    ? const Text('Oui')
                    : const Text('Yes'),
              ),
            ],
          ),
        )) ??
        false;
  }

  void _showPasDeContactAdd(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(25)),
      ),
      backgroundColor: isDark ? Color(0xFF1E1E1E) : Colors.white,
      builder: (_) => Container(
        padding: EdgeInsets.only(
          top: 12,
          left: 20,
          right: 20,
          bottom: MediaQuery.of(context).viewInsets.bottom + 30,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // --- Poignée de glissement ---
            Container(
              width: 40,
              height: 5,
              decoration: BoxDecoration(
                color: Colors.grey[300],
                borderRadius: BorderRadius.circular(10),
              ),
            ),
            SizedBox(height: 25),

            // --- EN-TÊTE : LE CONSTAT ---
            Icon(Icons.search_off_rounded, color: primaryColor, size: 50),
            SizedBox(height: 16),
            Text(
              (langUserPhone == "fr")
                  ? "Aucun contact disponible"
                  : "No Contacts Available",
              textAlign: TextAlign.center,
              style: GoogleFonts.poppins(
                fontSize: 22,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 10),
            Text(
              (langUserPhone == "fr")
                  ? "Pour le moment, aucun utilisateur correspondant à vos préférences n'a fait de boost."
                  : "Currently, no users matching your preferences have boosted.",
              textAlign: TextAlign.center,
              style: GoogleFonts.poppins(fontSize: 15, color: Colors.grey[600]),
            ),
            SizedBox(height: 30),

            // --- TITRE DES SOLUTIONS ---
            Text(
              (langUserPhone == "fr")
                  ? "Que faire maintenant ?"
                  : "What to do now?",
              style: GoogleFonts.poppins(
                  fontSize: 18, fontWeight: FontWeight.w600),
            ),
            SizedBox(height: 20),

            // --- CARTE D'ACTION 1 : FAIRE UN BOOST ---
            _buildActionCard(
              context: context,
              icon: Icons.rocket_launch_outlined,
              title:
                  (langUserPhone == "fr") ? "Faire un Boost" : "Make a Boost",
              subtitle: (langUserPhone == "fr")
                  ? "Soyez proactif ! Obtenez de nombreux contacts instantanément."
                  : "Be proactive! Get many contacts instantly.",
              buttonText: (langUserPhone == "fr")
                  ? "Démarrer un Boost"
                  : "Start a Boost",
              buttonColor: primaryColor,
              onTap: () {
                Navigator.pop(context); // Ferme la modale avant de naviguer
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => NewBoostContactPage()),
                );
              },
            ),
            SizedBox(height: 15),

            // --- CARTE D'ACTION 2 : PARTAGER ---
          ],
        ),
      ),
    );
  }

// --- WIDGET HELPER POUR LES CARTES D'ACTION ---
  Widget _buildActionCard({
    required BuildContext context,
    required IconData icon,
    required String title,
    required String subtitle,
    required String buttonText,
    required Color buttonColor,
    required VoidCallback onTap,
  }) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Container(
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: isDark ? Colors.grey[850] : Colors.white,
        borderRadius: BorderRadius.circular(15),
        border:
            Border.all(color: isDark ? Colors.grey[800]! : Colors.grey[200]!),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: buttonColor, size: 24),
              SizedBox(width: 12),
              Text(title,
                  style: GoogleFonts.poppins(
                      fontSize: 16, fontWeight: FontWeight.bold)),
            ],
          ),
          SizedBox(height: 8),
          Text(
            subtitle,
            style: GoogleFonts.poppins(color: Colors.grey[600], fontSize: 14),
          ),
          SizedBox(height: 16),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: onTap,
              child: Text(buttonText,
                  style: GoogleFonts.poppins(fontWeight: FontWeight.w600)),
              style: ElevatedButton.styleFrom(
                backgroundColor: buttonColor,
                foregroundColor: Colors.white,
                padding: EdgeInsets.symmetric(vertical: 12),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10)),
              ),
            ),
          ),
        ],
      ),
    );
  } // ---------------------------------------------------------------------------

  // BOTTOM MODAL D'INFORMATION
  // ---------------------------------------------------------------------------
  void _showRewardInfo(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) => Container(
        padding: EdgeInsets.all(24),
        decoration: BoxDecoration(
          color: theme.scaffoldBackgroundColor,
          borderRadius: BorderRadius.vertical(top: Radius.circular(30)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Barre de drag
            Container(
              width: 40,
              height: 5,
              decoration: BoxDecoration(
                color: Colors.grey[300],
                borderRadius: BorderRadius.circular(10),
              ),
            ),
            SizedBox(height: 25),

            // Icône et Titre
            Icon(Icons.stars, color: primaryColor, size: 50),
            SizedBox(height: 15),
            Text(
              "Promotion Éligible !",
              style: GoogleFonts.poppins(
                fontSize: 22,
                fontWeight: FontWeight.bold,
                color: theme.textTheme.titleLarge?.color,
              ),
            ),
            SizedBox(height: 10),
            Text(
              "Cette promotion fait partie du programme de récompenses Dressur.",
              textAlign: TextAlign.center,
              style: GoogleFonts.poppins(
                fontSize: 14,
                color: isDark ? Colors.grey[400] : Colors.grey[600],
              ),
            ),

            SizedBox(height: 30),

            // Détails fictifs
            _infoRow(context, Icons.visibility, "Objectif",
                "Atteindre min. 250 vues"),
            _infoRow(context, Icons.account_balance_wallet, "Gain estimé",
                "Jusqu'à 2 500 FCFA"),
            _infoRow(context, Icons.timer, "Délai", "20 heures de visibilité"),

            SizedBox(height: 30),

            // Bouton d'action
            SizedBox(
              width: double.infinity,
              height: 55,
              child: ElevatedButton(
                onPressed: () => Navigator.pop(context),
                style: ElevatedButton.styleFrom(
                  backgroundColor: primaryColor,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(15),
                  ),
                ),
                child: Text(
                  "J'ai compris",
                  style: GoogleFonts.poppins(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
            SizedBox(height: 10),
          ],
        ),
      ),
    );
  }

  Widget _infoRow(
      BuildContext context, IconData icon, String label, String value) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Padding(
      padding: const EdgeInsets.only(bottom: 15),
      child: Row(
        children: [
          Container(
            padding: EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: primaryColor.withOpacity(0.1),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(icon, color: primaryColor, size: 20),
          ),
          SizedBox(width: 15),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                style: GoogleFonts.poppins(
                  fontSize: 12,
                  color: isDark ? Colors.grey[400] : Colors.grey[600],
                ),
              ),
              Text(
                value,
                style: GoogleFonts.poppins(
                  fontSize: 15,
                  fontWeight: FontWeight.w600,
                  color: Theme.of(context).textTheme.bodyLarge?.color,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_firstLoad) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        // actualise(false);
      });
      setState(() {
        _firstLoad = false;
      });
    }
    return WillPopScope(
      onWillPop: _onWillPop,
      child: Scaffold(
        appBar: AppBar(
          automaticallyImplyLeading: false,
          elevation: 0,
          backgroundColor: primaryColor,
          title: Text(
            (langUserPhone == "fr") ? "Actu" : "News",
            style: GoogleFonts.poppins(
              color: Colors.white,
              fontWeight: FontWeight.w400,
            ),
          ),
          actions: [
            IconButton(
              icon: const Icon(
                Icons.notifications,
                color: Colors.white,
              ),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => ListeNotification(),
                  ),
                );
              },
            ),
            const Padding(
              padding: EdgeInsets.fromLTRB(0, 10, 0, 10),
              child: VerticalDivider(
                width: 0,
                color: Colors.white,
                thickness: 1,
              ),
            ),
            PopupMenuButton<int>(
              itemBuilder: (context) => [
                PopupMenuItem(
                  value: 1,
                  onTap: () {
                    _loading ? '' : actualise(true);
                  },
                  child: Row(
                    children: [
                      Text(
                        (langUserPhone == "fr") ? "Actualiser" : "Refresh",
                        style: GoogleFonts.poppins(
                          color: Colors.white,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),
                PopupMenuItem(
                  value: 2,
                  child: Row(
                    children: [
                      Text(
                        (langUserPhone == "fr") ? "Aide" : "Help",
                        style: GoogleFonts.poppins(
                          color: Colors.white,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
              offset: const Offset(0, 60),
              color: primaryColor,
              icon: const Icon(
                Icons.menu,
                color: Colors.white,
              ),
              elevation: 2,
              onSelected: (value) {
                if (value == 2) {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => SupportPage()),
                  );
                }
              },
            ),
          ],
        ),
        body: Column(
          children: [
            Expanded(
              child: RefreshIndicator(
                onRefresh: _refreshData,
                child: ListView(
                  controller: _scrollController,
                  children: [
                    const SizedBox(height: 10),
                    // Affiche la checklist des actions requises
                    _buildActionChecklist(
                      context: context,
                      showTel: !telIsVerified && mailIsVerified,
                      showMail: !mailIsVerified,
                      showProfile:
                          (nom.toString().replaceAll(' ', '').isEmpty ||
                              nom == null),
                      showBoost: (nombreContactDispo <= 100 &&
                          boostEnCours == false &&
                          telIsVerified &&
                          mailIsVerified),
                    ),
                    const SizedBox(height: 10),
                    // Affiche la carte de mise à jour si nécessaire
                    if (int.parse(versionApp.toString().replaceAll(".", "")) <
                        int.parse(myDressurVersion
                            .toString()
                            .replaceAll(".", ""))) ...[
                      _buildUpdateCard(
                        context: context,
                        onUpdate: () async {
                          final Uri _url = Uri.parse(dressurUrlPlaystore);
                          if (!await launchUrl(_url,
                              mode: LaunchMode.externalApplication)) {
                            throw 'Could not launch $_url';
                          }
                        },
                      ),
                      const SizedBox(height: 10),
                    ],

                    if (nombreContactDispo > 0) ...[
                      _buildAvailableContactsCard(
                        context: context,
                        contactCount: nombreContactDispo,
                        isLoading: _loading,
                        onRefresh: () => actualise(true),
                        onSaveAll: () {
                          if (!telIsVerified) {
                            showConfNumeroWhatsapp(context);
                          } else {
                            addTousLesContacts();
                          }
                        },
                        onGoToContacts: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => ContactPage()),
                          );
                        },
                      ),
                      const SizedBox(height: 10),
                    ],
                    if (havePublicites == true)
                      FutureBuilder<List<Advertisement>>(
                        future: _futureAdvertisements,
                        builder: (context, snapshot) {
                          if (snapshot.connectionState ==
                              ConnectionState.waiting) {
                            return const Center(
                              child: CircularProgressIndicator(),
                            );
                          } else if (snapshot.hasError) {
                            return Center(
                              child: Text('Erreur: ${snapshot.error}'),
                            );
                          } else if (!snapshot.hasData ||
                              snapshot.data!.isEmpty) {
                            return const Center(
                              child: null,
                            );
                          } else {
                            return ListView.builder(
                              shrinkWrap: true,
                              physics: const NeverScrollableScrollPhysics(),
                              itemCount: snapshot.data!.length,
                              itemBuilder: (context, index) {
                                Advertisement advertisement =
                                    snapshot.data![index];
                                return Container(
                                  margin: const EdgeInsets.only(
                                      left: 7, top: 0, right: 7, bottom: 0),
                                  child: Column(
                                    children: [
                                      Card(
                                        child: Column(
                                          children: [
                                            GestureDetector(
                                              onTap: () {
                                                setPromotionToWatch(
                                                    advertisement);
                                                Navigator.push(
                                                  context,
                                                  MaterialPageRoute(
                                                    builder: (context) =>
                                                        AdvertisementDetailPage(
                                                      advertisement:
                                                          advertisement,
                                                    ),
                                                  ),
                                                );
                                              },
                                              child: Column(
                                                children: [
                                                  Stack(
                                                    children: [
                                                      ClipRRect(
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(10),
                                                        child:
                                                            CachedNetworkImage(
                                                          imageUrl:
                                                              advertisement
                                                                  .image,
                                                          placeholder: (context,
                                                                  url) =>
                                                              Image.asset(
                                                                  'images/placeholder.png'),
                                                          errorWidget: (context,
                                                                  url, error) =>
                                                              Image.asset(
                                                                  'images/error_image.png'),
                                                          fit: BoxFit.cover,
                                                        ),
                                                      ),

                                                      // BADGE ÉLIGIBILITÉ (Affiche si inProgrammeRecompense est vrai)
                                                      if (advertisement
                                                          .inProgrammeRecompense)
                                                        Positioned(
                                                          top: 10,
                                                          right: 10,
                                                          child:
                                                              AnimatedRewardBadge(
                                                            onTap: () =>
                                                                _showRewardInfo(
                                                                    context),
                                                          ),
                                                        ),
                                                    ],
                                                  ),
                                                  const SizedBox(height: 10),
                                                  Padding(
                                                    padding: const EdgeInsets
                                                        .fromLTRB(12, 0, 12, 5),
                                                    child: Column(
                                                      children: [
                                                        Text(
                                                          advertisement
                                                              .description
                                                              .replaceAll(
                                                                  '\n', ' '),
                                                          maxLines: 4,
                                                          overflow: TextOverflow
                                                              .ellipsis,
                                                          style: GoogleFonts
                                                              .poppins(
                                                                  fontSize: 15,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w400),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            // les icons
                                            _buildActionFooter(
                                              context: context,
                                              impressionCount: advertisement
                                                  .nombreImpression,
                                              viewCount:
                                                  advertisement.nombreDeVues,
                                              onShare: () {
                                                sharePromotion(
                                                  context,
                                                  advertisement.image,
                                                  advertisement.imageName,
                                                  advertisement.description,
                                                );
                                              },
                                            ),
                                          ],
                                        ),
                                      ),
                                      const SizedBox(height: 5),
                                    ],
                                  ),
                                );
                              },
                            );
                          }
                        },
                      ),
                    const SizedBox(height: 5),
                    SociauxPage(),
                    const SizedBox(height: 10),
                    // essai notification
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildActionChecklist({
    required BuildContext context,
    required bool showTel,
    required bool showMail,
    required bool showProfile,
    required bool showBoost,
  }) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    // Liste des actions à afficher
    final List<Widget> actions = [];

    if (showTel) {
      actions.add(_buildActionItem(
        context,
        icon: Icons.phone_android_rounded,
        text: (langUserPhone == "fr")
            ? "Confirmer le numéro WhatsApp"
            : "Confirm WhatsApp Number",
        onTap: () => showConfNumeroWhatsapp(context),
      ));
    }
    if (showMail) {
      actions.add(_buildActionItem(
        context,
        icon: Icons.mail_outline_rounded,
        text: (langUserPhone == "fr")
            ? "Confirmer l'adresse e-mail"
            : "Confirm E-mail Address",
        onTap: () => Navigator.push(context,
            MaterialPageRoute(builder: (context) => CodeMailConfirmePage())),
      ));
    }
    if (showProfile) {
      actions.add(_buildActionItem(
        context,
        icon: Icons.person_outline_rounded,
        text: (langUserPhone == "fr")
            ? "Compléter votre profil"
            : "Complete Your Profile",
        onTap: () => Navigator.push(
            context, MaterialPageRoute(builder: (context) => ProfilPage())),
      ));
    }
    if (showBoost) {
      actions.add(_buildActionItem(
        context,
        icon: Icons.rocket_launch_outlined,
        text: (langUserPhone == "fr")
            ? "Activer le Boost Contact"
            : "Activate Boost Contact",
        onTap: () => _showPasDeContactAdd(context),
      ));
    }

    // Ne rien afficher si la liste est vide
    if (actions.isEmpty) return SizedBox.shrink();

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 0),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: isDark ? Color(0xFF1E1E1E) : Colors.white,
        borderRadius: BorderRadius.circular(15),
        border:
            Border.all(color: isDark ? Colors.grey[800]! : Colors.grey[200]!),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            (langUserPhone == "fr")
                ? "Pour commencer, vous devez :"
                : "To get started, you need to:",
            style: GoogleFonts.poppins(
              fontSize: 16,
              fontWeight: FontWeight.w600,
              color: isDark ? Colors.white : Colors.black87,
            ),
          ),
          SizedBox(height: 10),
          // Affiche les actions avec des séparateurs
          ...List.generate(actions.length, (index) {
            return Column(
              children: [
                if (index > 0)
                  Divider(
                      color: isDark ? Colors.grey[800] : Colors.grey[200],
                      height: 1),
                actions[index],
              ],
            );
          }),
        ],
      ),
    );
  }

// Helper pour chaque ligne de la checklist
  Widget _buildActionItem(BuildContext context,
      {required IconData icon,
      required String text,
      required VoidCallback onTap}) {
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 12.0),
        child: Row(
          children: [
            Icon(icon, color: Colors.redAccent, size: 24),
            SizedBox(width: 16),
            Expanded(
              child: Text(
                text,
                style: GoogleFonts.poppins(
                    fontSize: 15, fontWeight: FontWeight.w500),
              ),
            ),
            Icon(Icons.arrow_forward_ios_rounded,
                size: 16, color: Colors.grey[400]),
          ],
        ),
      ),
    );
  }

// Helper pour la carte de mise à jour
  Widget _buildUpdateCard(
      {required BuildContext context, required VoidCallback onUpdate}) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 0),
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [Colors.red, Colors.redAccent.shade700],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.red.withOpacity(0.3),
            blurRadius: 12,
            offset: Offset(0, 5),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.system_update_rounded, color: Colors.white, size: 30),
              SizedBox(width: 12),
              Text(
                (langUserPhone == "fr")
                    ? "Mise à jour requise"
                    : "Update Required",
                style: GoogleFonts.poppins(
                  color: Colors.white,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
          SizedBox(height: 12),
          Text(
            (langUserPhone == "fr")
                ? "Une nouvelle version est disponible. Mettez à jour pour bénéficier des dernières fonctionnalités et améliorations de sécurité."
                : "A new version is available. Update now to get the latest features and security improvements.",
            style: GoogleFonts.poppins(
              color: Colors.white.withOpacity(0.9),
              fontSize: 14,
              height: 1.5,
            ),
          ),
          SizedBox(height: 16),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: onUpdate,
              icon: Icon(Icons.download_for_offline_rounded, color: Colors.red),
              label: Text(
                (langUserPhone == "fr")
                    ? "Mettre à jour maintenant"
                    : "Update Now",
                style: GoogleFonts.poppins(
                    fontWeight: FontWeight.bold, color: Colors.red),
              ),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.white,
                padding: EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12)),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAvailableContactsCard({
    required BuildContext context,
    required int contactCount,
    required bool isLoading,
    required VoidCallback onRefresh,
    required VoidCallback onSaveAll,
    required VoidCallback onGoToContacts,
  }) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 0),
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [primaryColor, primaryColor.withOpacity(0.2)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(15),
        boxShadow: [
          BoxShadow(
            color: primaryColor.withOpacity(0.3),
            blurRadius: 15,
            offset: Offset(0, 5),
          ),
        ],
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                (langUserPhone == "fr")
                    ? "Contacts Disponibles"
                    : "Available Contacts",
                style: GoogleFonts.poppins(
                  color: Colors.white,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              IconButton(
                onPressed: isLoading ? null : onRefresh,
                icon: Icon(Icons.refresh_rounded,
                    color: Colors.white.withOpacity(0.8)),
                tooltip: (langUserPhone == "fr") ? "Actualiser" : "Refresh",
              ),
            ],
          ),

          Text(
            contactCount.toString(),
            style: GoogleFonts.poppins(
                color: Colors.white,
                fontSize: 64,
                fontWeight: FontWeight.bold,
                shadows: [
                  Shadow(blurRadius: 10, color: Colors.black.withOpacity(0.2))
                ]),
          ),
          Text(
            (langUserPhone == "fr")
                ? "nouveau(x) contact(s) à enregistrer"
                : "new contact(s) to save",
            style: GoogleFonts.poppins(
              color: Colors.white.withOpacity(0.9),
              fontSize: 14,
              fontWeight: FontWeight.w500,
            ),
          ),
          SizedBox(height: 10),

          // --- BOUTONS D'ACTION ---
          Row(
            children: [
              // --- BOUTON PRINCIPAL "ENREGISTRER TOUS" ---
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: isLoading ? null : onSaveAll,
                  icon: isLoading
                      ? Container(
                          // Spinner de chargement
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(
                            strokeWidth: 2.5,
                            color: primaryColor,
                          ),
                        )
                      : Icon(Icons.download_for_offline_rounded,
                          color: primaryColor),
                  label: Text(
                    isLoading
                        ? ((langUserPhone == "fr") ? "Patientez..." : "Wait...")
                        : ((langUserPhone == "fr")
                            ? "Enregistrer Tous"
                            : "Save All"),
                    style: GoogleFonts.poppins(
                      fontWeight: FontWeight.bold,
                      color: isLoading ? Colors.grey[600] : primaryColor,
                    ),
                  ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.white,
                    padding: EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12)),
                  ),
                ),
              ),
              SizedBox(width: 12),

              // --- BOUTON SECONDAIRE "MES CONTACTS" ---
              Expanded(
                child: OutlinedButton(
                  onPressed: onGoToContacts,
                  style: OutlinedButton.styleFrom(
                    side: BorderSide(color: Colors.white.withOpacity(0.6)),
                    foregroundColor: Colors.white,
                    padding: EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12)),
                  ),
                  child: Text(
                    (langUserPhone == "fr") ? "Mes Contacts" : "My Contacts",
                    style: GoogleFonts.poppins(fontWeight: FontWeight.w600),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildActionFooter({
    required BuildContext context,
    required String impressionCount,
    required String viewCount,
    required VoidCallback onShare,
  }) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    return Container(
      // Ajout d'une bordure supérieure pour séparer visuellement le footer du contenu

      padding: const EdgeInsets.fromLTRB(12, 0, 12, 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          // --- PARTIE STATISTIQUES (à gauche) ---
          Row(
            children: [
              _buildStatItem(
                icon: Icons.visibility_outlined,
                value: impressionCount.toString(),
                label: (langUserPhone == "fr") ? "Impressions" : "Impressions",
              ),
              SizedBox(width: 15),
              _buildStatItem(
                icon: Icons.touch_app_outlined,
                value: viewCount.toString(),
                label: (langUserPhone == "fr") ? "Vues" : "Views",
              ),
            ],
          ),

          // --- PARTIE ACTION "PARTAGER" (à droite) ---
          ElevatedButton.icon(
            onPressed: onShare,
            icon: Icon(Icons.share, size: 18),
            label: Text(
              (langUserPhone == "fr") ? "Partager" : "Share",
              style: GoogleFonts.poppins(fontWeight: FontWeight.w600),
            ),
            style: ElevatedButton.styleFrom(
              backgroundColor: primaryColor.withOpacity(0.1),
              foregroundColor: primaryColor,
              elevation: 0, // Pas d'ombre pour un look plat et moderne
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
              padding: EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            ),
          ),
        ],
      ),
    );
  }

// Helper pour afficher un item de statistique (icône + valeur)
  Widget _buildStatItem(
      {required IconData icon, required String value, required String label}) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Icon(icon, color: Colors.grey[600], size: 20),
        SizedBox(width: 8),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              value,
              style: GoogleFonts.poppins(
                fontWeight: FontWeight.bold,
                fontSize: 18,
              ),
            ),
            Text(
              label,
              style: GoogleFonts.poppins(
                color: Colors.grey[600],
                fontSize: 9,
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
      ],
    );
  }
}

class AdvertisementDetailPage extends StatelessWidget {
  final Advertisement advertisement;

  AdvertisementDetailPage({required this.advertisement});

  Future<void> _launchURL(String url) async {
    final Uri uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      print('Could not launch $url');
    }
  }

  void openWhatsAppChat() async {
    String text;
    if (langUserPhone == "fr") {
      text =
          "Bonjour/Bonsoir *${advertisement.pseudoAnnonceur}*, j'ai une question concernant la promotion ci-dessous: \n\n";
    } else {
      text =
          "Good morning or Good evening *${advertisement.pseudoAnnonceur}*, I have a question regarding the promotion below: \n\n";
    }

    // Vérification de la longueur de la description
    if (advertisement.description.length >= 100) {
      text +=
          "<<${advertisement.description.substring(0, 100)}...>>\n\n*Depuis Dressur.*";
    } else {
      text += "<<${advertisement.description}>>\n\n*Depuis Dressur.*";
    }

    String encodedText = Uri.encodeComponent(text);

    String url =
        'https://wa.me/${advertisement.whatsappNumber}?text=$encodedText';

    final Uri _url = Uri.parse(url);
    if (!await launchUrl(_url, mode: LaunchMode.externalApplication)) {
      throw 'Could not launch $_url';
    }
  }

  void _showRewardInfo(BuildContext context) {
    showModalBottomSheet(
      context: context,
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(25))),
      builder: (context) => Container(
        padding: EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.stars, color: primaryColor, size: 40),
            SizedBox(height: 10),
            Text("Promotion Éligible",
                style: GoogleFonts.poppins(
                    fontWeight: FontWeight.bold, fontSize: 18)),
            SizedBox(height: 10),
            Text("Partagez cette promotion pour gagner des récompenses !"),
            SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final Map<String, dynamic> infoMap = (advertisement.annotherInfo != "")
        ? jsonDecode(advertisement.annotherInfo)
        : {};

    return Scaffold(
      appBar: AppBar(
        backgroundColor: primaryColor,
        foregroundColor: Colors.white,
        title: Text(
          (langUserPhone == "fr")
              ? 'Détails de la promotion'
              : 'Promotion Details',
          style: GoogleFonts.poppins(fontWeight: FontWeight.w600),
        ),
      ),
      body: SingleChildScrollView(
        physics: BouncingScrollPhysics(),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // --- AFFICHE DE LA PROMOTION (AFFICHAGE COMPLET) ---
            Stack(
              children: [
                CachedNetworkImage(
                  imageUrl: advertisement.image,
                  placeholder: (context, url) => AspectRatio(
                    aspectRatio:
                        16 / 9, // Un ratio commun pour les placeholders
                    child: Container(color: Colors.grey[200]),
                  ),
                  errorWidget: (context, url, error) => AspectRatio(
                    aspectRatio: 16 / 9,
                    child: Container(
                        color: Colors.grey[200], child: Icon(Icons.error)),
                  ),
                  // `fit: BoxFit.contain` pourrait aussi être une option si vous voulez des bandes noires
                  // mais `fit: BoxFit.cover` avec `width: double.infinity` est souvent le meilleur compromis.
                  width: double.infinity,
                  fit: BoxFit
                      .fitWidth, // Affiche l'image en pleine largeur, hauteur ajustée
                ),
                if (advertisement.inProgrammeRecompense)
                  Positioned(
                    top: 10,
                    right: 10,
                    child: AnimatedRewardBadge(
                        onTap: () => _showRewardInfo(context)),
                  ),
              ],
            ),

            // --- CONTENU TEXTUEL ---
            Padding(
              padding: const EdgeInsets.all(15.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // --- TITRE ---

                  SizedBox(height: 15),

                  // --- BARRE DE STATS ET CONTACT ---
                  _buildContactBar(context),
                  SizedBox(height: 25),

                  // --- DESCRIPTION ---
                  _buildSectionTitle(
                      icon: Icons.description_outlined,
                      title: (langUserPhone == "fr")
                          ? "Description"
                          : "Description"),
                  SelectableLinkify(
                    onOpen: (link) => _launchURL(link.url),
                    text: advertisement.description,
                    style: GoogleFonts.poppins(fontSize: 14, height: 1.6),
                    // --- STYLE DES LIENS SANS SOULIGNEMENT ---
                    linkStyle: GoogleFonts.poppins(
                      color: Colors.blue,
                      fontWeight: FontWeight.w500,
                      decoration: TextDecoration.none, // Enlève le soulignement
                    ),
                  ),
                  SizedBox(height: 30),

                  // --- INFORMATIONS SUPPLÉMENTAIRES ---
                  if (infoMap.isNotEmpty) ...[
                    _buildSectionTitle(
                        icon: Icons.info_outline_rounded,
                        title: (langUserPhone == "fr")
                            ? "Informations supplémentaires"
                            : "Additional Information"),
                    ...infoMap.entries.map((entry) {
                      final key =
                          StringExtension(entry.key.replaceAll('_', ' '))
                              .capitalize();
                      final value = entry.value;
                      return _buildInfoRow(key, value);
                    }).toList(),
                  ],
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // --- WIDGETS HELPERS ---

  Widget _buildContactBar(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 0, vertical: 0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          // Stats
          Row(
            children: [
              Icon(Icons.visibility_outlined,
                  color: Colors.grey[600], size: 20),
              SizedBox(width: 4),
              Text(advertisement.nombreImpression.toString(),
                  style: GoogleFonts.poppins(
                      fontSize: 18, fontWeight: FontWeight.w600)),
              SizedBox(width: 12),
              Icon(Icons.touch_app_outlined, color: Colors.grey[600], size: 20),
              SizedBox(width: 4),
              Text(advertisement.nombreDeVues.toString(),
                  style: GoogleFonts.poppins(
                      fontSize: 18, fontWeight: FontWeight.w600)),
            ],
          ),
          // Bouton de contact
          ElevatedButton.icon(
            onPressed: openWhatsAppChat,
            icon: FaIcon(FontAwesomeIcons.whatsapp, size: 18),
            label: Text(
              (langUserPhone == "fr") ? "Contacter" : "Contact",
              style: GoogleFonts.poppins(fontWeight: FontWeight.bold),
            ),
            style: ElevatedButton.styleFrom(
              backgroundColor: Color.fromRGBO(37, 211, 102, 0.5),
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10)),
              padding: EdgeInsets.symmetric(horizontal: 18, vertical: 8),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionTitle({required IconData icon, required String title}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10.0),
      child: Row(
        children: [
          Icon(icon, color: primaryColor, size: 22),
          SizedBox(width: 10),
          Text(title,
              style: GoogleFonts.poppins(
                  fontSize: 18, fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }

  Widget _buildInfoRow(String key, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            key,
            style: GoogleFonts.poppins(
                fontSize: 14,
                color: Colors.grey[600],
                fontWeight: FontWeight.w500),
          ),
          SizedBox(height: 4),
          SelectableLinkify(
            onOpen: (link) => _launchURL(link.url),
            text: value,
            style:
                GoogleFonts.poppins(fontSize: 16, fontWeight: FontWeight.w500),
            linkStyle: GoogleFonts.poppins(
                color: Colors.blue, decoration: TextDecoration.none),
          ),
          Divider(height: 12),
        ],
      ),
    );
  }
}

extension StringExtension on String {
  String capitalize() {
    if (this.isEmpty) return "";
    return "${this[0].toUpperCase()}${this.substring(1)}";
  }
}
